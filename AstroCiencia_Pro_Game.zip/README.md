# AstroCiencia Pro 🚀

¡Bienvenido a AstroCiencia Pro!  
Un juego educativo y divertido para niños donde aprender ciencia es una aventura en el espacio.

## Cómo jugar
- Mueve la nave con **flechas izquierda/derecha**.
- Dispara rayos con **barra espaciadora** para destruir meteoritos.
- Cada 3 niveles aparecerán **preguntas de ciencia**.
- Responde correctamente para ganar puntos, o si fallas, verás la explicación del dato.

## Requisitos
- Navegador moderno: Chrome, Edge, Firefox.
- ¡No requiere instalación!

## Créditos
Creado con HTML5 y JavaScript.
